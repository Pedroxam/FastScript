<?php if(!defined('FS_ACCESS')) die('Direct Access Not Allowed !'); ?>

<div class="col-md-12 mt-3 p-1 mb-4 text-center bg-white text-danger">

	<div class="col-md-12 mt-3">
	
		<div class="card p-4 text-center">
		
			<?php

				// Example Using Some Function in 'functions.php' on theme folder.
				
				echo SimpleProject('Lion');

			?>
			
		</div>
		
	</div>

</div>