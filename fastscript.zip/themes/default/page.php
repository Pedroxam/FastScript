<?php if(!defined('FS_ACCESS')) die('Direct Access Not Allowed !'); ?>

<div class="main-content-wrap sidenav-close d-flex flex-column">

	<div class="row">

		<div class="col-md-12 mt-3 p-1 mb-4 text-center bg-white text-danger">

			<div class="col-md-12 mt-3">
			
				<div class="card p-4 text-dark">
					
					<h3 class="mb-4">This is <?php echo currentURI(); ?></h3>
					
					<p class="p-1">Fast Script is Starter Project - This is Build With Very Easy PHP Coding.</p>
					
					<p class="p-1">This makes it possible to create your own project and provide it to your customers at the fastest time.</p>
					
					<p class="p-1">Browse the files and folders in the script to learn how to use functions and classes.</p>
					
					<p class="p-1">The admin panel feature and the theme's default theme are built-in, which makes it quicker for you</p>
					
					<p class="p-1">Provide your script with a admin panel and several options to your customers.</p>
					
					<p class="p-1">Also, the "cache" feature is already included to the script, so, See the "function.php" file in the theme folder to better understand for how to use this class.</p>
					
					<p class="p-1"> In the future, more option and class's will be added to the project.</p>
					
				</div>
				
			</div>

		</div>

	</div>

</div>