<?php if(!defined('FS_ACCESS')) die('Direct Access Not Allowed !'); ?>
<!--All Theme Scripts-->
<script src="<?php echo get_theme_directory_uri(); ?>/assets/js/jquery-3.3.1.min.js"></script>
<script src="<?php echo get_theme_directory_uri(); ?>/assets/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo get_theme_directory_uri(); ?>/assets/js/perfect-scrollbar.min.js"></script>
<script src="<?php echo get_theme_directory_uri(); ?>/assets/js/main.script.min.js"></script>
<script src="<?php echo get_theme_directory_uri(); ?>/assets/js/script.min.js"></script>
</body>
</html>