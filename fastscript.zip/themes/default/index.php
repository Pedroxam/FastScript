<?php if(!defined('FS_ACCESS')) die('Direct Access Not Allowed !'); ?>

<div class="main-content-wrap sidenav-close d-flex flex-column">

<div class="row">

	<div class="col-md-12 mb-4">
		<div class="card p-4 text-center">
			<h2 class="mt-4">BUILD YOUR PROJECT</h2>
			<h2 class="mt-4">By</h2>
			<h2 class="mt-4">F A S T . S C R I P T</h2>
		</div>
	</div>

	<?php

		//Example Including File in Theme Directory

		get_site_part('part');

	?>
	
	<div class="col-md-12 mb-4">
		<div class="card p-4 text-center">
			<a href="<?php echo URL; ?>page/">Click Here For Show Sample Page</a>
		</div>
	</div>
	
	

</div>

</div>