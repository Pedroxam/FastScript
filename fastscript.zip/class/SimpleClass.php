<?php

namespace SimpleClass\SimpleClass;

/**
 * Simple Using Class and Using Cache Class.
 */
class SimpleClass
{
		//Simple Function
		public function myProjectByCache($name) {
			
			return $name . ' in The SimpleClass.php';
			
		}
		
}
?>